	################################
	Configuration ContosoWebServerDSC {
	
	    Node "webserver"
	
	        {
	        #Install the IIS Role 
	
	        WindowsFeature IIS 
	        { 
	            Ensure = "Present"
	            Name = "Web-Server"
	        } 
	    }
	}
################################