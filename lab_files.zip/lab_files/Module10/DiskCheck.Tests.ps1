$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = "$(Split-Path $here -Parent)\Scripts\" + $MyInvocation.MyCommand
$script = $sut.Replace("DiskCheck.Tests.", "DiskCheck.")
#$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path).Replace(".Tests.", ".")
. $script

Describe "DiskCheck.ps1" {
    
    It "Should return an object" {

        Mock Get-WMIObject {Return @{
            DriveName = "C"
            VolumeName = "Windows"
            FreeSpace = 12383828
            Size = 123332932391
        }}

        $x = Get-LocalDisks
        $x | Should Not Be Null
    }

    It "Should return multiple objects if multiple disks" {

        Mock Get-WMIObject {Return @{
            DriveName = "C"
            VolumeName = "Windows"
            FreeSpace = 12383828
            Size = 123332932391
      },
      @{
            DriveName = "D"
            VolumeName = "Data"
            FreeSpace = 12383828
            Size = 123332932391
        }}
        
        $x = Get-LocalDisks
        $x.Count | Should Be 2

    }
}