Function Get-LocalService
{
    Param ([string]$ServiceName)

    $service = Get-Service -Name $ServiceName

    return $service.Status
}