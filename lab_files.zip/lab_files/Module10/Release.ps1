Param (
    [string]$ResourceGroupName,
    [string]$AutomationAccountName
)

$files = Get-ChildItem "$env:SYSTEM_ARTIFACTSDIRECTORY\$env:BUILD_DEFINITIONNAME\RunbookScripts\" -Exclude Release.ps1

Write-Output $files

$automationAccount = Get-AzureRMAutomationAccount -ResourceGroupName $ResourceGroupName -AutomationAccountName $automationAccountName

Write-Output $automationAccount

foreach ($file in $files)
{
    $automationAccount | Import-AzureRmAutomationRunbook -Name ($file.Name).Replace(".ps1","") -Path $file.Fullname -Type PowerShell -Force
}

