$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = "$(Split-Path $here -Parent)\Scripts\" + $MyInvocation.MyCommand
$script = $sut.Replace("ServiceCheck.Tests.", "ServiceCheck.")
#$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path).Replace(".Tests.", ".")
. $script

Describe "ServiceCheck.ps1" {

    It "Should return a status of stopped" {
        Mock Get-Service {return @{Status="Stopped"}}
        Get-LocalService -ServiceName FakeService | Should Be "Stopped"

    }    
}