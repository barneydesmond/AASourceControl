﻿Function Get-LocalDisks 
{
$disks = Get-WmiObject Win32_LogicalDisk

$diskArray = @()

Foreach ($disk in $disks)
    {

    $diskArray += [PSCustomObject]@{
        DriveName = $disk.DeviceID
        VolumeName = $disk.VolumeName
        FreespacePercentage = "{0:P}" -f ($disk.FreeSpace / $disk.Size)
        }
    }

return $diskArray
}
        