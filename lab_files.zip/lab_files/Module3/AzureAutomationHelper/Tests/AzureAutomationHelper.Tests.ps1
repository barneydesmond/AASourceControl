$ModulePath = Resolve-Path -Path "$PSScriptRoot\..\..\AzureAutomationHelper" | ForEach-Object Path
$ModuleName = Get-ChildItem -Path $ModulePath -Filter *.psm1 | Select-Object -First 1 -ExpandProperty FullName
Write-Output $ModuleName
Remove-Module AzureAutomationHelper -Force -ErrorAction SilentlyContinue
Import-Module -FullyQualifiedName $ModuleName -Force


    Describe "Module Unit Tests" {   
        Context "Monitor-CompilationJob" {
            Mock Get-AzureRmAutomationDscCompilationJob {return @{Status="Suspended"}} -ParameterFilter {$AutomationAccountName -eq "SuspendedJob"} -ModuleName AzureAutomationHelper
            Mock Get-AzureRmAutomationDscCompilationJob {return @{Status="Completed"}} -ParameterFilter {$AutomationAccountName -eq "CompletedJob"} -ModuleName AzureAutomationHelper
            $automationAccountCompleted = @{
                ResourceGroupName = "TestResourceGroupName"
                AutomationAccountName = "CompletedJob"
            }
            $automationAccountSuspended = @{
                ResourceGroupName = "TestResourceGroupName"
                AutomationAccountName = "SuspendedJob"
            }
            Mock Write-Output {} -ModuleName AzureAutomationHelper

            It "Should stop if completed" {
                Monitor-CompilationJob -JobID (New-GUID).Guid -AutomationAccount $automationAccountCompleted -Delay 0 | Should Be "Completed"
            }
            It "Should stop if suspended" {
                Monitor-CompilationJob -JobID (New-GUID).Guid -AutomationAccount $automationAccountSuspended -Delay 0 | Should Be "Suspended"
            }
        }

        Context "Import-CompileDSCConfiguration" {

        }

        Context "Install-AzureAutomationModule" {

        }

        Context "Monitor-NodeStatus" {

        }

        Context "Add-ValueToVariable" {
            $hash = @{
                Value1 = "One"
            }
            It "Should return a hashtable" {
                Add-ValueToVariable -Hashtable $hash -Name Value2 -Value "Two" | Should BeOfType HashTable
            }
            It "Should add a value" {
                $obj = Add-ValueToVariable -Hashtable $hash -Name Value3 -Value "Three"
                $obj.Value3 | Should Be "Three"
            }
        }

        Context "Save-VariablesToFile" {
            $hash = @{
                Value1 = "One"
            }
            It "Creates the file if it doesn't exists" {
                Save-VariablesToFile -Hashtable $hash -Path "TestDrive:\Variables.json"
                Test-Path "TestDrive:\Variables.json" | Should Be $true
            }
        }
    }

Remove-Module AzureAutomationHelper -Force -ErrorAction SilentlyContinue