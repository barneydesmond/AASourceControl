#region Pre-Requisites

Set-Location $env:SystemDrive\Labs\Module3

Import-Module -FullyQualifiedName .\AzureAutomationHelper\AzureAutomationHelper.psm1

$variables = Get-Content .\Variables.json | ConvertFrom-Json | ConvertPSObjectToHashtable

Write-Output $variables

#endregion Pre-Requisites

#region Exercise 1 - Logging in to Microsoft Azure

Login-AzureRmAccount

#endregion 

#region Exercise 2 - Resource Groups

$location = (Get-AzureRmLocation | Where-Object Providers -Contains Microsoft.Automation | Out-GridView -PassThru).Location
Add-ValueToVariable -Hashtable $variables -Name Location -Value $location

New-AzureRmResourceGroup -Name $variables.ResourceGroupName -Location $location -Verbose

#endregion Exercise 2 - Resource Groups

<#region Exercise 3 - Automation Account Creation

This step must be performed in the Azure Portal in order to create the Run As accounts. 

When the deployment has finished in the portal you can run the code below to load the Automation Account

#>

$automationAccount = Get-AzureRmAutomationAccount -ResourceGroupName $Variables.ResourceGroupName -Name $variables.AutomationAccountName

Write-Output $automationAccount | Select-Object -Property *

#endregion Exercise 3 - Automation Account Creation

#region Exercise 4 - Importing a runbook

$automationAccount | Import-AzureRmAutomationRunbook -Name "Contoso_PowerShell_Script" -Path .\Contoso_PowerShell_Script.ps1 -Type PowerShell

#endregion Exercise 4 - Importing a runbook

#region Exercise 5 - Assets

$adminCred = Get-Credential -Message "Enter the password for the VM local administrator account" -UserName $variables.LocalUserName
$domainCred = Get-Credential -Message "Enter the password for the domain administrator" -UserName $variables.DomainUserName

$automationAccount | New-AzureRmAutomationVariable -Name DomainName -Value $variables.DomainName -Description "Domain Name" -Verbose -Encrypted $false

$automationAccount | New-AzureRmAutomationCredential -Name DomainAdminAccount -Value $domainCred -Verbose

$automationAccount | New-AzureRmAutomationCredential -Name AdminAccount -Value $adminCred -Verbose

Add-ValueToVariable -Hashtable $variables -Name LocalPassword -Value ($adminCred.GetNetworkCredential().Password)
Add-ValueToVariable -Hashtable $variables -Name DomainPassword -Value ($adminCred.GetNetworkCredential().Password)

#endregion Exercise 5 - Assets

#region SAVE VARIABLES

Save-VariablesToFile -Hashtable $variables -Path .\Variables.json

#endregion SAVE VARIABLES






