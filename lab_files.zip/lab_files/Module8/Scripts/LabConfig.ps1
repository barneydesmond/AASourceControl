﻿#To do - use the PDT module to run the SCORCH install process

Configuration LabConfig
{

    $domainName = Get-AutomationVariable -Name "DomainName"
    $adminCredentials = Get-AutomationPSCredential -Name "AdminAccount"
    $domainadminCredentials = Get-AutomationPSCredential -Name "DomainAdminAccount"
    $subscriptionID = Get-AutomationVariable -Name "SubscriptionID"
    $workspacename = Get-AutomationVariable -Name "WorkspaceName"
    $resourceGroupName = Get-AutomationVariable -Name "ResourceGroupName"
    $automationAccoutName = Get-AutomationVariable -Name "AutomationAccountName"

    Import-DscResource -ModuleName PSDesiredStateConfiguration,xActiveDirectory,xDSCDomainJoin

    Node DomainController
        {
            WindowsFeature DNS_RSAT
            { 
                Ensure = "Present"
                Name = "RSAT-DNS-Server"
            }
 
            WindowsFeature ADDS_Install 
            { 
                Ensure = 'Present'
                Name = 'AD-Domain-Services'
            } 
 
            WindowsFeature RSAT_AD_AdminCenter 
            {
                Ensure = 'Present'
                Name   = 'RSAT-AD-AdminCenter'
            }
 
            WindowsFeature RSAT_ADDS 
            {
                Ensure = 'Present'
                Name   = 'RSAT-ADDS'
            }
 
            WindowsFeature RSAT_AD_PowerShell 
            {
                Ensure = 'Present'
                Name   = 'RSAT-AD-PowerShell'
            }
 
            WindowsFeature RSAT_AD_Tools 
            {
                Ensure = 'Present'
                Name   = 'RSAT-AD-Tools'
            }
 
            WindowsFeature RSAT_Role_Tools 
            {
                Ensure = 'Present'
                Name   = 'RSAT-Role-Tools'
            }      
 
            WindowsFeature RSAT_GPMC 
            {
                Ensure = 'Present'
                Name   = 'GPMC'
            } 
            xADDomain CreateForest 
            { 
                DomainName = $domainName           
                DomainAdministratorCredential = $adminCredentials
                SafemodeAdministratorPassword = $adminCredentials
                DatabasePath = "C:\Windows\NTDS"
                LogPath = "C:\Windows\NTDS"
                SysvolPath = "C:\Windows\Sysvol"
                DependsOn = '[WindowsFeature]ADDS_Install'
            }
        }

    Node HybridRunbookWorker
        {
            xDSCDomainjoin DomainJoin
            {
                Domain = $domainName
                Credential = $domainadminCredentials
            }

            Registry AdminUserNoIEESC
            {
                Key = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
                ValueName = "IsInstalled"
                ValueData = 0
                Ensure = "Present"
                DependsOn = '[xDSCDomainjoin]DomainJoin'
            }

            Registry NormalUserNoIEESC
            {
                Key = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
                ValueName = "IsInstalled"
                ValueData = 0
                Ensure = "Present"
                DependsOn = '[xDSCDomainjoin]DomainJoin'
            }

            Script InstallScript
            {
                GetScript = {return @{Present = $true}}
                TestSCript = {
                    return Test-Path 'C:\Program Files\WindowsPowerShell\Scripts\New-OnPremiseHybridWorker.ps1'
                }
                SetScript = {
                    Install-Script -Name New-OnPremiseHybridWorker -MinimumVersion 1.0 -Force -Confirm:$false
                }
                DependsOn = '[xDSCDomainjoin]DomainJoin'
            }

            Script InstallModule
            {
                GetScript = {return @{Present = $true}}
                TestScript = {
                    if ((Get-Module -ListAvailable | Where-Object Name -Like "AzureRM.*" | Measure-Object).Count -gt 0)
                    {
                        return $true
                    }
                    else
                    {
                        return $false
                    }
                }
                SetScript = {
                    Install-Module -Name AzureRM -Force -Confirm:$false
                }
                DependsOn = '[xDSCDomainjoin]DomainJoin'
            }  

            Script InstallRunbookWorker
            {
                GetScript = {return @{Present = $true}}
                TestScript = {
                    return Test-Path 'C:\Program Files\WindowsPowerShell\Scripts\Temp.txt'
            }
                SetScript = {
                    Set-Location 'C:\Program Files\WindowsPowerShell\Scripts\'
                    <#$azureCred = New-Object System.Management.Automation.PSCredential ($using:UserName, (ConvertTo-SecureString $using:Password -AsPlainText -Force))
                    .\New-OnPremiseHybridWorker.ps1 -ResourceGroupName $using:resourceGroupName `
                    -SubscriptionID $using:subscriptionID `
                    -AutomationAccountName $using:automationAccoutName `
                    -WorkspaceName $using:workspacename `
                    -HybridGroupName Master `
                    -Credential $azureCred
                    -Verbose#>
                    Write-Verbose "Microsoft accounts are not supported for login so lets just create a file"
                    $params = @{
                        ResourceGroupName = $using:resourceGroupName 
                        SubscriptionID = $using:subscriptionID 
                        AutomationAccountName = $using:automationAccoutName 
                        WorkspaceName = $using:workspacename 
                        HybridGroupName = "Master" 
                    }
                    $params.GetEnumerator() | Out-File Parameters.txt
                }
                DependsOn = '[xDSCDomainjoin]DomainJoin','[Script]InstallScript','[Script]InstallModule'

            }

    
    }
}
