﻿<#
TODO: Write test for module file - 50%
TODO: Add as job for Monitor function
TODO: Save the state after each section - functions written
TODO: Randomise the public ip names
TODO: Name the deployments
#>

#region Variables

Set-Location $env:SystemDrive\Students\Labs\Module8

Import-Module -FullyQualifiedName .\AzureAutomationHelper\AzureAutomationHelper.psm1

Set-Location $env:SystemDrive\Students\Labs\Module8\Scripts

$variables = Get-Content .\variables.json | ConvertFrom-Json | ConvertPSObjectToHashtable

Write-Output $variables

#endregion Variables

#region Login to Azure 

Login-AzureRmAccount

$subscriptionID = Get-AzureRmSubscription | Select-Object -ExpandProperty ID
Add-ValueToVariable -Hashtable $variables -Name SubscriptionID -Value $subscriptionID

#endregion Login to Azure

#region Create the Resource Group

$storageAccountName = ($variables.AutomationAccountName.ToLower()+(Get-Random -Maximum 2048)).Substring(10)

$adminCred = Get-Credential -Message "Enter the password for the VM local administrator account" -UserName $variables.LocalUserName
$domainCred = Get-Credential -Message "Enter the password for the domain administrator" -UserName "$($variables.DomainName.Split(".")[0])`\$($variables.LocalUserName)"
#$AzureCred = Get-Credential -Message "Enter the username and password to connect to your Azure Subscription"

$Location = (Get-AzureRmLocation | Where-Object Providers -Contains Microsoft.Automation | Out-GridView -PassThru).Location
Add-ValueToVariable -Hashtable $variables -Name Location -Value $Location
Add-ValueToVariable -Hashtable $variables -Name StorageAccountName -Value $storageAccountName
Add-ValueToVariable -Hashtable $variables -Name LocalPassword -Value ($adminCred.GetNetworkCredential().Password)
Add-ValueToVariable -Hashtable $variables -Name DomainPassword -Value ($adminCred.GetNetworkCredential().Password)

New-AzureRmResourceGroup -Name $variables.ResourceGroupName -Location $variables.Location -Verbose

Save-VariablesToFile -Hashtable $variables -Path .\VariablesNew.json

#endregion Create the Resource Group



#region Create the Automation Account in the portal so it creates the service accounts

# NOTE!!!!!  This step must be performed in the Azure Portal in order to create the Run As accounts !!!!!!
# NOTE!!!!!  After the account is created you can run the code in this region to load the account   !!!!!!

$variables = Get-Content .\VariablesNew.json | ConvertFrom-Json | ConvertPSObjectToHashtable

Write-Output $variables

try
    {
        $automationAccount = Get-AzureRmAutomationAccount -ResourceGroupName $variables.ResourceGroupName -Name $variables.AutomationAccountName -ErrorAction STOP
        Write-Output "Found automation account: $($automationAccount.AutomationAccountName) in resource group: $($automationAccount.ResourceGroupName)"
    }
catch
    {
        Write-Output "Ensure that the automation account has been created manually in the portal before continuing."
        Read-Host "Press any key to exit....."
        exit
    }

#endregion Create the Automation Account in the portal so it creates the service accounts



#region Deploy DSC Resource Modules

Set-Location $variables.SourceLocation

Install-AzureAutomationModule -AutomationAccountName $variables.AutomationAccountName `
                                -ResourceGroupName $variables.ResourceGroupName `
                                -AutomationAccountLocation $variables.Location `
                                -AccountStatus "Existing" `
                                -TemplateFile ".\ModuleDeployment\xActiveDirectory_template.json"

Install-AzureAutomationModule -AutomationAccountName $variables.AutomationAccountName `
                                -ResourceGroupName $variables.ResourceGroupName `
                                -AutomationAccountLocation $variables.Location `
                                -TemplateFile ".\ModuleDeployment\xDSCDomainJoin_template.json"

#region Deploy DSC Resource Modules


#region Create the automation account Assets

Set-Location $env:SystemDrive\Students\Labs\Module8\Scripts
$variables = Get-Content .\VariablesNew.json | ConvertFrom-Json | ConvertPSObjectToHashtable
$adminCred = New-Object System.Management.Automation.PSCredential ($variables.LocalUserName, (ConvertTo-SecureString $variables.LocalPassword -AsPlainText -Force))
$domainCred = New-Object System.Management.Automation.PSCredential ($variables.DomainUserName, (ConvertTo-SecureString $variables.DomainPassword -AsPlainText -Force))

If ($automationAccount | Get-AzureRmAutomationVariable -Name DomainName -ErrorAction SilentlyContinue){
$automationAccount | Remove-AzureRmAutomationVariable -Name DomainName 
$automationAccount | New-AzureRmAutomationVariable -Name DomainName -Value $variables.DomainName -Description "Domain Name" -Verbose -Encrypted $false
}
Else
{
$automationAccount | New-AzureRmAutomationVariable -Name DomainName -Value $variables.DomainName -Description "Domain Name" -Verbose -Encrypted $false
}

$automationAccount | New-AzureRMAutomationVariable -Name SubscriptionID -Value $variables.SubscriptionID -Description "SubscriptionID" -Verbose -Encrypted $false

$automationAccount | New-AzureRMAutomationVariable -Name ResourceGroupName -Value $variables.ResourceGroupName -Description "Resource Group Name" -Verbose -Encrypted $false

$automationAccount | New-AzureRMAutomationVariable -Name AutomationAccountName -Value $variables.AutomationAccountName -Description "Automation Account Name" -Verbose -Encrypted $false

$automationAccount | New-AzureRMAutomationVariable -Name WorkspaceName -Value $variables.storageAccountName -Description "OMS Workspace Name" -Verbose -Encrypted $false

If ($automationAccount | Get-AzureRmAutomationCredential -Name DomainAdminAccount -ErrorAction SilentlyContinue){
$automationAccount | Remove-AzureRmAutomationCredential -Name DomainAdminAccount 
$automationAccount | New-AzureRmAutomationCredential -Name DomainAdminAccount -Value $domainCred -Verbose
}
Else
{
$automationAccount | New-AzureRmAutomationCredential -Name DomainAdminAccount -Value $domainCred -Verbose
}

If ($automationAccount | Get-AzureRmAutomationCredential -Name AdminAccount -ErrorAction SilentlyContinue){
$automationAccount | Remove-AzureRmAutomationCredential -Name AdminAccount 
$automationAccount | New-AzureRmAutomationCredential -Name AdminAccount -Value $adminCred -Verbose
}
Else
{
$automationAccount | New-AzureRmAutomationCredential -Name AdminAccount -Value $adminCred -Verbose
}

#$automationAccount | New-AzureRmAutomationCredential -Name AzureCredential -Value $AzureCred -Verbose

$automationAccount | Get-AzureRmAutomationVariable | Select Name | Format-Table
$automationAccount | Get-AzureRmAutomationCredential | Select Name | Format-Table

#endregion Create the automation account Assets



#region Import and Compile the Configurations

Set-Location "$($variables.SourceLocation)\Scripts"

$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName = "*"
            PSDscAllowPlainTextPassword = $True
            PSDscAllowDomainUser = $True
         },
        @{
            NodeName = "DomainController"
         },
        @{
            NodeName = "HybridRunbookWorker"
         }
    )
}

$configuration = (Get-Item .\LabConfig.ps1).FullName

Import-CompileDSCConfiguration -ResourceGroupName $variables.ResourceGroupName `
                                -AutomationAccountName $variables.AutomationAccountName `
                                -ConfigurationPath $configuration `
                                -ConfigurationData $ConfigurationData `
                                -Compile 
                                

$automationAccount | Get-AzureRmAutomationDscNodeConfiguration | Select Name | Format-Table

#endregion Import and Compile the Configurations

#region Deploy Domain Controller

Set-Location $variables.SourceLocation

if (!(Test-Path "$(Get-Location)\Parameters"))
    {
        New-Item -Name Parameters -ItemType Directory -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "_parameter" | ForEach-Object {Copy-Item $_.FullName .\Parameters}
    }
else
    {
        Remove-Item -Path .\Parameters\*.* -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "_parameter" | ForEach-Object {Copy-Item $_.FullName .\Parameters}
    }

$paramFile = Get-Content -Path .\Parameters\domaincontroller_parameters.json | ConvertFrom-Json

$paramFile.parameters.storageAccountName.value = $variables.StorageAccountName
$paramFile.parameters.adminUsername.value = $variables.LocalUserName
$paramFile.parameters.adminPassword.value = $variables.LocalPassword
$paramFile.parameters.location.value = $variables.Location

$paramFile | ConvertTo-Json | Out-File .\Parameters\domaincontroller_parameters.json

if (!(Test-Path "$(Get-Location)\LabServerDeploymentUpdate"))
    {
        New-Item -Name LabServerDeploymentUpdate -ItemType Directory -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "domaincontroller.json" | ForEach-Object {Copy-Item $_.FullName .\LabServerDeploymentUpdate}
    }
else
    {
        Remove-Item -Path .\LabServerDeploymentUpdate\*.* -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "domaincontroller.json" | ForEach-Object {Copy-Item $_.FullName .\LabServerDeploymentUpdate}
    }

$newFile = New-Item .\LabServerDeploymentUpdate\domaincontrollerUpdate.json -ItemType File -Force

switch -Regex (Get-Content .\LabServerDeploymentUpdate\domaincontroller.json)
{
    {$_ -match "TempResourceGroupName"} {$string = $_.Replace("TempResourceGroupName",$variables.ResourceGroupName); Out-File -FilePath $newFile -InputObject $string -Append}
    Default {$string = $_; Out-File -FilePath $newFile -InputObject $_ -Append}
}

New-AzureRmResourceGroupDeployment -ResourceGroupName $variables.ResourceGroupName `
                      -TemplateFile .\LabServerDeploymentUpdate\domaincontrollerUpdate.json `
                      -TemplateParameterFile .\Parameters\domaincontroller_parameters.json `
                      -Verbose

$DCipAddress = (Get-AzureRmNetworkInterface -ResourceGroupName $variables.ResourceGroupName).IpConfigurations[0].PrivateIpAddress

Add-ValueToVariable -Hashtable $variables -Name DCIPAddress -Value $DCipAddress
Save-VariablesToFile -Hashtable $variables -Path .\Scripts\VariablesNew.json

#endregion Deploy Domain Controller

#region Register node and apply the configuration

$azureVMName = (Get-AzureRMVM -Name STH-DC01 -ResourceGroupName $variables.ResourceGroupName).Name
$nodeConfigurationName = "LabConfig.DomainController"

$automationAccount | Register-AzureRmAutomationDscNode -AzureVMName $azureVMName `
                -NodeConfigurationName $nodeConfigurationName `
                -ConfigurationMode ApplyAndAutocorrect `
                -RebootNodeIfNeeded $true `
                -ActionAfterReboot ContinueConfiguration `
                -Verbose `
                -AzureVMResourceGroup $variables.ResourceGroupName `
                -AzureVMLocation $variables.Location

$nodeID = ($automationAccount | Get-AzureRmAutomationDscNode -Name $azureVMName | Sort-Object RegistrationTime | Select-Object -Last 1).ID
                
Monitor-NodeStatus -AutomationAccount $automationAccount -NodeID $nodeID -DesiredState Compliant -RetryCount 50 -Verbose              
                
#endregion Register node and apply the configuration

#region Update the DNS Settings

Set-Location $($variables.SourceLocation)

if (!(Test-Path "$(Get-Location)\Parameters"))
    {
        New-Item -Name Parameters -ItemType Directory -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "vnet" | ForEach-Object {Copy-Item $_.FullName .\Parameters}
    }
else
    {
        Remove-Item -Path .\Parameters\*.* -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "vnet" | ForEach-Object {Copy-Item $_.FullName .\Parameters}
    }

$newFile = New-Item .\Parameters\vNETLocationUpdate.json -ItemType File -Force

switch -Regex (Get-Content .\Parameters\vNetUpdate.json)
{
    {$_ -match "location"} {Out-File -FilePath $newFile -InputObject "`"location`": `"$($variables.Location)`"," -Append}
    {$_ -match '"dnsServerAddress": "x.x.x.x",'} {Out-File -FilePath $newFile -InputObject "`"dnsServerAddress`": `"$DCipAddress`"," -Append}
    Default {$string = $_; Out-File -FilePath $newFile -InputObject $_ -Append}
}

New-AzureRmResourceGroupDeployment -ResourceGroupName $variables.ResourceGroupName `
                                    -TemplateFile .\Parameters\vNetLocationUpdate.json `
                                    -Verbose

#endregion Update the DNS Settings

#region Deploy OMS Workspace

Set-Location $($variables.SourceLocation)

New-AzureRmResourceGroupDeployment -ResourceGroupName $variables.ResourceGroupName `
                                    -TemplateFile .\LabServerDeployment\oms.json `
                                    -nameFromTemplate $variables.StorageAccountName `
                                    -location $variables.Location `
                                    -sku "free" `
                                    -Verbose

Set-AzureRmOperationalInsightsIntelligencePack -ResourceGroupName $variables.ResourceGroupName `
                                               -WorkspaceName $variables.StorageAccountName `
                                               -IntelligencePackName AzureAutomation `
                                               -Enabled $true `
                                               -Verbose

#endregion Deploy OMS Workspace

#region Deploy Hybrid Runbook Worker

Set-Location $($variables.SourceLocation)

if (!(Test-Path "$(Get-Location)\Parameters"))
    {
        New-Item -Name Parameters -ItemType Directory -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "_parameter" | ForEach-Object {Copy-Item $_.FullName .\Parameters}
    }
else
    {
        Remove-Item -Path .\Parameters\*.* -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "_parameter" | ForEach-Object {Copy-Item $_.FullName .\Parameters}
    }

$paramFile = Get-Content -Path .\Parameters\hrw_parameters.json | ConvertFrom-Json

$paramFile.parameters.adminUsername.value = $variables.LocalUserName
$paramFile.parameters.adminPassword.value = $adminCred.GetNetworkCredential().Password
$paramFile.parameters.location.value = $variables.Location
$paramFile.parameters.storageAccountName.value = $variables.StorageAccountName+"hrw"

$paramFile | ConvertTo-Json | Out-File .\Parameters\hrw_parameters.json

if (!(Test-Path "$(Get-Location)\LabServerDeploymentUpdate"))
    {
        New-Item -Name LabServerDeploymentUpdate -ItemType Directory -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "hrw.json" | ForEach-Object {Copy-Item $_.FullName .\LabServerDeploymentUpdate}
    }
else
    {
        Remove-Item -Path .\LabServerDeploymentUpdate\*.* -Force
        Get-ChildItem .\LabServerDeployment | Where-Object Name -Match "hrw.json" | ForEach-Object {Copy-Item $_.FullName .\LabServerDeploymentUpdate}
    }

$newFile = New-Item .\LabServerDeploymentUpdate\hrwUpdate.json -ItemType File -Force

switch -Regex (Get-Content .\LabServerDeploymentUpdate\hrw.json)
{
    {$_ -match "TempResourceGroupName"} {$string = $_.Replace("TempResourceGroupName",$variables.ResourceGroupName); Out-File -FilePath $newFile -InputObject $string -Append}
    Default {$string = $_; Out-File -FilePath $newFile -InputObject $_ -Append}
}

New-AzureRmResourceGroupDeployment -ResourceGroupName $variables.ResourceGroupName `
                      -TemplateFile .\LabServerDeploymentUpdate\hrwupdate.json `
                      -TemplateParameterFile .\Parameters\hrw_parameters.json `
                      -Verbose

#endregion Deploy Hybrid Runbook Worker



#region Register Hybrid Runbook Worker

$azureVMName = (Get-AzureRMVM -Name STH-HRW01 -ResourceGroupName $variables.ResourceGroupName).Name
$nodeConfigurationName = "LabConfig.HybridRunbookWorker"

$automationAccount | Register-AzureRmAutomationDscNode -AzureVMName $azureVMName `
                -NodeConfigurationName $nodeConfigurationName `
                -ConfigurationMode ApplyAndAutocorrect `
                -RebootNodeIfNeeded $true `
                -ActionAfterReboot ContinueConfiguration `
                -Verbose `
                -AzureVMResourceGroup $variables.ResourceGroupName `
                -AzureVMLocation $variables.Location

$nodeID = ($automationAccount | Get-AzureRmAutomationDscNode -Name $azureVMName | Sort-Object RegistrationTime | Select-Object -Last 1).ID

Monitor-NodeStatus -AutomationAccount $automationAccount -NodeID $nodeID -DesiredState Compliant -RetryCount 100 -Verbose              

#endregion Hybrid Runbook Worker

#region Deploy a Runbook

Set-Location "$($variables.SourceLocation)\Scripts\RunbookExample"

$automationAccount | Import-AzureRmAutomationRunbook -Path .\HelloRunbookWorld.ps1 `
                                                    -Description "Hello World Runbook" `
                                                    -Name "Hello World" `
                                                    -Type PowerShell `
                                                    -Published

#endregion Deploy a Runbook









